package convertir;


public class Atributo {
	String nombre;
	String tipo;
	
	Atributo()
	{
		nombre = new String();
		tipo = new String();
	}
	
	Atributo(String nombre, String tipo)
	{
		this.nombre = nombre;
		this.tipo = tipo;
	}
}
